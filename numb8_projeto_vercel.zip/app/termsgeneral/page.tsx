export default function Terms() {
  return <iframe src="/termsgeneral.html" style={{position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', border: 'none'}} title="Terms" />;
}
